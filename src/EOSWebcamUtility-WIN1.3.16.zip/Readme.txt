EOS Webcam Utility Installation instructions:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- To install the EOS Webcam Utility, please run the "Setup.exe" file present in the installation folder.

- To uninstall the application, please select "EOS Webcam Utility" in the "Add or Remove programs" and select the "Uninstall" option.

